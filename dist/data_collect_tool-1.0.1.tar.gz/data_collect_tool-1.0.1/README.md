#Please read the instruction carefully before putting to use
#Check package at https://test.pypi.org/project/data-collect-tool/
