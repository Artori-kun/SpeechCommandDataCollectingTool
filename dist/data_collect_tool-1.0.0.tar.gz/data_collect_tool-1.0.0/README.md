#Please read the instruction carefully before putting to use
# Test DataCollectTool package